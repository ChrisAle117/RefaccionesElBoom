import React, { useState, useEffect, useRef } from 'react';
import { usePage } from '@inertiajs/react';
import { ProductCard } from './product-card';
import { Pagination } from './pagination';

interface Product {
    id_product: number;
    name: string;
    price: number;
    description: string;
    disponibility: number;
    image: string;
    active: boolean;
    type?: string;
}

type FilterOption = {
    id: string;
    label: string;
    isActive: boolean;
    applyFilter: (products: Product[]) => Product[];
};

export function ProductCatalog() {
    const { products: initialProducts = [], search = '', type = '', productTypes = [] } = usePage().props as { 
        products?: Product[], 
        search?: string,
        type?: string,
        productTypes?: string[] 
    };

    // Estado para manejar los productos filtrados
    const [filteredProducts, setFilteredProducts] = useState<Product[]>(initialProducts);
    
    // Estado para el tipo de producto seleccionado
    const [selectedType, setSelectedType] = useState<string>(type);

    // Estados para la paginación
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [productsPerPage, setProductsPerPage] = useState<number>(10);
    const [columnsCount, setColumnsCount] = useState<number>(5);
    const gridRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, [currentPage]);
    
    // Detectar el número de columnas del grid y ajustar productos por página
    useEffect(() => {
        const updateGridLayout = () => {
            if (!gridRef.current) return;
            
            // Obtener el estilo computado del grid
            const computedStyle = window.getComputedStyle(gridRef.current);
            const gridTemplateColumns = computedStyle.gridTemplateColumns;
            
            // Contar cuántas columnas tiene el grid
            const columns = gridTemplateColumns.split(' ').length;
            setColumnsCount(columns);
            
            // Calcular cuántas filas queremos mostrar
            const rowsToShow = window.innerWidth < 768 ? 5 : 3;
            
            // Ajustar productos por página para que sea múltiplo exacto del número de columnas
            const newProductsPerPage = columns * rowsToShow;
            
            // Solo actualizar si realmente cambió el valor y es la primera vez que se carga
            if (newProductsPerPage !== productsPerPage && productsPerPage === 10) {
                setProductsPerPage(newProductsPerPage);
                // No resetear la página aquí para evitar volver a la primera página
            }
        };
        updateGridLayout();
        
        // Configurar un observador de tamaño para el contenedor del grid
        if (gridRef.current && typeof ResizeObserver === 'function') {
            const resizeObserver = new ResizeObserver(() => {
                updateGridLayout();
            });
            resizeObserver.observe(gridRef.current);
            
            // Limpiar el observer cuando se desmonte el componente
            return () => {
                if (gridRef.current) {
                    resizeObserver.unobserve(gridRef.current);
                }
            };
        }
        
        window.addEventListener('resize', updateGridLayout);
        return () => {
            window.removeEventListener('resize', updateGridLayout);
        };
    }, []);

    // Estado para manejar los filtros
    const [filterOptions, setFilterOptions] = useState<FilterOption[]>([
        {
            id: 'price-desc',
            label: 'Precio: Mayor a menor',
            isActive: false,
            applyFilter: (products) => [...products].sort((a, b) => b.price - a.price)
        },
        {
            id: 'availability-desc',
            label: 'Disponibilidad: Mayor a menor',
            isActive: false,
            applyFilter: (products) => [...products].sort((a, b) => b.disponibility - a.disponibility)
        },
        {
            id: 'only-available',
            label: 'Solo productos disponibles',
            isActive: false,
            applyFilter: (products) => products.filter(p => p.disponibility > 0)
        },
        {
            id: 'price-asc',
            label: 'Precio: Menor a mayor',
            isActive: false,
            applyFilter: (products) => [...products].sort((a, b) => a.price - b.price)
        },
        {
            id: 'availability-asc',
            label: 'Disponibilidad: Menor a mayor',
            isActive: false,
            applyFilter: (products) => [...products].sort((a, b) => a.disponibility - b.disponibility)
        },
    ]);

    // Estado para mostrar/ocultar el menú de filtros
    const [showFilters, setShowFilters] = useState(false);

    // Función para manejar el cambio de tipo de producto
    const handleTypeFilter = (type: string) => {
        // Actualizar la URL con el nuevo tipo seleccionado
        const url = new URL(window.location.href);
        if (type) {
            url.searchParams.set('type', type);
        } else {
            url.searchParams.delete('type');
        }
        window.location.href = url.toString();
    };

    // Aplicar filtros cuando cambian las opciones o el tipo seleccionado
    useEffect(() => {
        let result = [...initialProducts].filter(p => p.active && p.disponibility > 0);
        
        // Filtrar por tipo si hay uno seleccionado
        if (selectedType) {
            result = result.filter(p => p.type === selectedType);
        }

        // Aplicar todos los filtros activos
        filterOptions.forEach(option => {
            if (option.isActive) {
                result = option.applyFilter(result);
            }
        });

        setFilteredProducts(result);
        if (JSON.stringify(result) !== JSON.stringify(filteredProducts)) {
            setCurrentPage(1);
        }
    }, [initialProducts, filterOptions, selectedType]);

    // Calcular índices de productos para la página actual
    const indexOfLastProduct = currentPage * productsPerPage;
    const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
    const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
    const totalPages = Math.ceil(filteredProducts.length / productsPerPage);

    // Navegación de páginas
    const goToPage = (pageNumber: number) => setCurrentPage(pageNumber);

    // Manejar cambio de filtro
    const handleFilterChange = (filterId: string) => {
        setFilterOptions(prevOptions =>
            prevOptions.map(option => {
                if (filterId.includes('price-') && option.id.includes('price-')) {
                    return {
                        ...option,
                        isActive: option.id === filterId ? !option.isActive : false
                    };
                }
                if (filterId.includes('availability-') && option.id.includes('availability-')) {
                    return {
                        ...option,
                        isActive: option.id === filterId ? !option.isActive : false
                    };
                }
                if (option.id === filterId) {
                    return { ...option, isActive: !option.isActive };
                }
                return option;
            })
        );
    };

    // Limpiar todos los filtros
    const clearAllFilters = () => {
        setFilterOptions(prevOptions =>
            prevOptions.map(option => ({ ...option, isActive: false }))
        );
    };

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(price);
    };

    return (
        <div className="p-2 sm:p-4 border-b-2 border-[#FBCC13]  text-bold text-white rounded shadow overflow-y-auto overflow-x-hidden relative w-full  max-w-none w-screen -ml-[calc(50vw-50%)] left-0 px-4 sm:px-6">
            {/* Header y acciones */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 flex-wrap bg-white p-3 rounded-md shadow-sm mb-3 dark:bg-gray-800">
                <h2 className="text-xl sm:text-2xl font-bold mb-1 sm:mb-2 text-black dark:text-white">Catálogo de productos.</h2>
                <div className="flex flex-row items-center gap-2 sm:gap-3 ">
                    {search.trim() && (
                        <p className="text-lg mb-2 mr-0 sm:mr-4 dark:text-gray-300">Resultado de búsqueda: {search}</p>
                    )}
                    <button
                        className="text-black text-sm sm:text-base hover:text-black transition duration-300 flex items-center cursor-pointer underline-offset-2 hover:underline dark:text-white dark:hover:text-yellow-400"
                        onClick={() => setShowFilters(!showFilters)}
                    >
                        {showFilters ? (
                            <><svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            Ocultar filtros</>
                        ) : (
                            <><svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                            </svg>
                            Filtrar productos</>
                        )}
                    </button>
                    <span className="text-gray-300 mx-1">|</span>
                    <button
                        className="text-black text-sm sm:text-base hover:text-black transition duration-300 flex items-center cursor-pointer underline-offset-2 hover:underline dark:text-white dark:hover:text-yellow-400"
                        onClick={() => {
                            setFilterOptions(prev => prev.map(o => ({ ...o, isActive: false })));
                            setSelectedType('');
                            const url = new URL(window.location.href);
                            url.searchParams.delete('search');
                            url.searchParams.delete('type');
                            window.location.href = url.toString();
                        }}
                    >
                        <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Limpiar búsqueda
                    </button>
                </div>
            </div>

            {/* Panel de filtros */}
            {showFilters && (
                <div className="bg-white text-black p-2 sm:p-4 rounded-md mt-1 mb-3 border border-gray-300 dark:bg-gray-800 dark:border-gray-600 shadow-sm">
                    <div className="flex flex-row justify-between items-center mb-3">
                        <h3 className="font-semibold text-base dark:text-gray-100">Filtrar por:</h3>
                        <button
                            className="text-blue-600 hover:text-[#FBCC13] transition duration-300 dark:text-blue-400 dark:hover:text-yellow-400 focus:outline-none"
                            onClick={clearAllFilters}
                            title="Limpiar todos los filtros"
                        >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </button>
                    </div>
                    <div className="mb-3">
                        <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Ordenar por:</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                            {filterOptions.map(option => (
                                <div key={option.id} className="flex items-center">
                                    <input
                                        type="checkbox"
                                        id={option.id}
                                        checked={option.isActive}
                                        onChange={() => handleFilterChange(option.id)}
                                        className="mr-2 h-4 w-4 text-[#006CFA] focus:ring-1 focus:ring-[#006CFA] rounded dark:text-blue-400 dark:focus:ring-blue-400"
                                    />
                                    <label htmlFor={option.id} className="text-sm dark:text-gray-300">
                                        {option.label}
                                    </label>
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    {/* Filtro por tipo de producto */}
                    {productTypes && productTypes.length > 0 && (
                        <div>
                            <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Tipo de producto:</h4>
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                                {productTypes.map((type, index) => (
                                    <div key={`type-${index}`} className="flex items-center">
                                        <input
                                            type="radio"
                                            id={`type-${index}`}
                                            name="product-type"
                                            checked={selectedType === type}
                                            onChange={() => handleTypeFilter(type)}
                                            className="mr-2 h-4 w-4 text-[#006CFA] focus:ring-1 focus:ring-[#006CFA] rounded-full dark:text-blue-400 dark:focus:ring-blue-400"
                                        />
                                        <label htmlFor={`type-${index}`} className="text-sm dark:text-gray-300">
                                            {type || 'Sin clasificar'}
                                        </label>
                                    </div>
                                ))}
                                <div className="flex items-center">
                                    <input
                                        type="radio"
                                        id="type-all"
                                        name="product-type"
                                        checked={selectedType === ''}
                                        onChange={() => handleTypeFilter('')}
                                        className="mr-2 h-4 w-4 text-[#006CFA] focus:ring-1 focus:ring-[#006CFA] rounded-full dark:text-blue-400 dark:focus:ring-blue-400"
                                    />
                                    <label htmlFor="type-all" className="text-sm dark:text-gray-300">
                                        Todos
                                    </label>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}

            

            {/* Grid de productos */}
            <div 
                ref={gridRef}
                className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 3xl:grid-cols-8 gap-3 sm:gap-4 md:gap-5 w-full p-2 product-grid-container"
            >
                {currentProducts.length > 0 ? (
                    currentProducts.map((product) => (
                        <ProductCard key={product.id_product} {...product} />
                    ))
                ) : (
                    <p className="col-span-full text-center py-8 bg-white dark:bg-gray-800 rounded-md p-4 font-medium">No hay productos disponibles con los filtros seleccionados.</p>
                )}
            </div>

            {/* Paginación y selector de productos por página */}
            {filteredProducts.length > 0 && (
                <div className="mt-5 bg-white rounded-md p-3 dark:bg-gray-800 shadow-sm">
                    <Pagination 
                        currentPage={currentPage}
                        totalPages={totalPages}
                        totalItems={filteredProducts.length}
                        itemsPerPage={productsPerPage}
                        currentItems={currentProducts.length}
                        onPageChange={goToPage}
                        onItemsPerPageChange={(newValue) => {
                            const adjustedValue = Math.ceil(newValue / columnsCount) * columnsCount;
                            setProductsPerPage(adjustedValue);
                            setCurrentPage(1);
                        }}
                        itemsPerPageOptions={[
                            columnsCount * 2,  
                            columnsCount * 3,  
                            columnsCount * 4   
                        ]}
                        showItemsPerPageSelector={true}
                    />
                </div>
            )}
        </div>
    );
}