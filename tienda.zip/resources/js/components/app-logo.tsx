import AppLogoIcon from './app-logo-icon';

export default function AppLogo() {
    return (
        <>
            <div className="">
                <AppLogoIcon className="size-5 fill-current text-white dark:text-black" />
            </div>
            
        </>
    );
}
