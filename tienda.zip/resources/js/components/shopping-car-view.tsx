import React, { useState, useEffect } from 'react';
import { useShoppingCart } from './shopping-car-context';
import { Trash2, ShoppingCart, CreditCard } from 'lucide-react';
import { Inertia } from '@inertiajs/inertia';

const toInt = (v: unknown, fallback = 0) => {
    const n = Number.parseInt(String(v), 10);
    return Number.isFinite(n) ? n : fallback;
};

export function ShoppingCarView() {
    const { cartItems, totalPrice, removeFromCart, updateItem } = useShoppingCart();
    const [showDeleteMsg, setShowDeleteMsg] = useState(false);
    const [quantities, setQuantities] = useState<Record<number, number>>({});
    const [inputValues, setInputValues] = useState<Record<number, string>>({});
    const [showMaxAlert, setShowMaxAlert] = useState<boolean>(false);

    //envío gratis
    const MIN_PURCHASE_FOR_FREE_SHIPPING = 2000;

    useEffect(() => {
        const newQuantities: Record<number, number> = {};
        const newInputValues: Record<number, string> = {};

        cartItems.forEach(item => {
            const q = toInt(item.quantity, 1);
            newQuantities[item.id_product] = q;
            newInputValues[item.id_product] = String(q);
        });

        setQuantities(newQuantities);
        setInputValues(newInputValues);
    }, [cartItems]);

    // Calcular el total de unidades de productos en el carrito
    const totalUnits = cartItems.reduce((sum, item) => sum + toInt(item.quantity, 0), 0);

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(price);
    };

    return (
        <div className="relative w-full mx-auto bg-white dark:bg-gray-900 min-h-screen pb-20">
            {/* Mensaje de producto eliminado */}
            {showDeleteMsg && (
                <div className={`fixed top-6 left-1/2 transform -translate-x-1/2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-6 py-3 rounded-xl shadow-lg z-50 pointer-events-none transition-opacity duration-700 ${showDeleteMsg ? 'opacity-100' : 'opacity-0'}`}>
                    Producto eliminado
                </div>
            )}

            {/* Alerta de cantidad máxima */}
            {showMaxAlert && (
                <div className={`fixed top-6 left-1/2 transform -translate-x-1/2 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-6 py-3 rounded-xl shadow-lg z-50 pointer-events-none transition-opacity duration-700 ${showMaxAlert ? 'opacity-100' : 'opacity-0'}`}>
                    Has alcanzado el límite máximo de unidades disponibles
                </div>
            )}
            <div className="sticky top-0 z-10 bg-gradient-to-b from-white to-transparent dark:from-gray-900 dark:to-gray-800 backdrop-blur-md p-6 border-b-2 border-[#FBCC13] dark:border-gray-700 shadow-lg rounded-b-xl hidden sm:block w-full">
                <div className="flex justify-between items-center flex-wrap gap-4">
                    <h2 className="text-2xl font-extrabold text-black dark:text-white flex items-center gap-2">
                        <ShoppingCart className="h-6 w-6" /> Carrito de compras
                    </h2>
                    <span className="text-lg font-bold text-black dark:text-white  px-4 py-2 rounded shadow border-none">Cantidad: {totalUnits}</span>
                    <h3 className="text-lg font-bold text-black dark:text-white px-4 py-2 rounded shadow">Total: {formatPrice(totalPrice)}</h3>
                    <img className='h-20 w-20 object-contain rounded-full border-2 border-[#FBCC13] dark:border-[#006CFA] shadow' src={document.documentElement.classList.contains('dark') ? '/images/logotipo-claro.png' : '/images/logotipo.png'} alt="" />
                </div>

                {/* Barra de progreso para envío gratis*/}
                <div className="mt-4 w-full">
                    {/* Camión sobre la barra */}
                    <div className="relative w-full mb-6">
                        <div
                            className="absolute z-10"
                            style={{
                                left: `${Math.max(Math.min(totalPrice / MIN_PURCHASE_FOR_FREE_SHIPPING * 100, 100), 7)}%`,
                                bottom: '100%',
                                transform: 'translateX(-50%)'
                            }}
                        >
                            <img
                                src="/images/trailer.png"
                                width="150"
                                height="150"
                                alt="Camión de entrega"
                                className={`${totalPrice >= MIN_PURCHASE_FOR_FREE_SHIPPING ? 'animate-bounce' : ''}`}
                                style={{ marginBottom: '8px' }}
                            />
                        </div>
                        <div className="w-full h-4 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-gradient-to-r from-[#FBCC13] to-[#006CFA] dark:from-[#006CFA] dark:to-[#FBCC13] rounded-full transition-all duration-500"
                                style={{ width: `${Math.min(totalPrice / MIN_PURCHASE_FOR_FREE_SHIPPING * 100, 100)}%` }}
                            >
                            </div>
                        </div>
                        <div className="flex justify-between mt-2 text-sm">
                            <span className="text-black dark:text-white font-medium">
                                {totalPrice >= MIN_PURCHASE_FOR_FREE_SHIPPING
                                    ? '¡Felicidades! Tienes envío gratis'
                                    : `Faltan ${formatPrice(MIN_PURCHASE_FOR_FREE_SHIPPING - totalPrice)} para envío gratis`
                                }
                            </span>
                            <span className="text-black dark:text-white font-semibold">{formatPrice(MIN_PURCHASE_FOR_FREE_SHIPPING)}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="sticky top-0 z-10 bg-gradient-to-b from-white to-transparent dark:from-gray-900 dark:to-gray-800 backdrop-blur-md p-4 border-b-2 border-[#FBCC13] dark:border-gray-700 shadow-lg rounded-b-xl sm:hidden w-full">
                <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-3 mb-2">
                        <span className="text-xl font-extrabold text-black dark:text-white flex items-center gap-2"><ShoppingCart className="h-5 w-5" /> Carrito</span>
                    </div>
                    <div className="flex flex-row justify-between items-center">
                        <span className="text-base font-bold text-black dark:text-white bg-[#FBCC13] dark:bg-[#006CFA] px-3 py-1 rounded shadow">Cantidad: {totalUnits}</span>
                        <span className="text-base font-bold text-[#006CFA] dark:text-[#FBCC13] bg-[#FBCC13] dark:bg-[#006CFA] px-3 py-1 rounded shadow">Total: {formatPrice(totalPrice)}</span>
                    </div>
                </div>
            </div>
            {cartItems.length === 0 ? (
                <div className="p-8 text-center text-black dark:text-white flex flex-col items-center justify-center">
                    <ShoppingCart className="h-24 w-24 mb-4 text-gray-400" />
                    <p className="text-lg font-semibold">No hay productos en el carrito.</p>
                </div>
            ) : (
                <ul className="mt-4 flex flex-col gap-6">
                    {cartItems.map((item) => (
                        <li key={item.id_product} className="">
                            <div className="flex flex-row p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-[#FBCC13] dark:border-[#006CFA] max-sm:hidden w-full transition-transform hover:scale-[1.01] items-center gap-6">
                                <div className="flex items-center gap-4 flex-1">
                                    <img className="w-24 h-24 object-contain rounded-lg border-2 border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900" src={item.image || (document.documentElement.classList.contains('dark') ? '/images/logotipo-claro.png' : '/images/logotipo.png')} alt={item.name} />
                                    <div>
                                        <h3 className="text-lg font-bold text-black dark:text-white mb-1">
                                            {item.name} <span className="text-gray-500 dark:text-gray-400">(x{item.quantity})</span>
                                        </h3>
                                        <p className="text-sm text-gray-600 dark:text-gray-400">Precio unidad: <span className="font-bold">{formatPrice(Number(item.price))}</span></p>
                                        <p className="text-sm text-gray-600 dark:text-gray-400">Disponibles: <span className="font-bold">{item.disponibility}</span></p>
                                    </div>
                                </div>
                                <div className="flex flex-col items-center gap-2 justify-center">
                                    <div className="flex items-center border border-gray-300 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900 shadow min-w-[140px] justify-center">
                                        <button
                                            onClick={() => {
                                                const currentQuantity = toInt(quantities[item.id_product] ?? item.quantity, 1);
                                                if (currentQuantity > 1) {
                                                    const newQuantity = currentQuantity - 1;
                                                    setQuantities({
                                                        ...quantities,
                                                        [item.id_product]: newQuantity
                                                    });
                                                    setInputValues({
                                                        ...inputValues,
                                                        [item.id_product]: newQuantity.toString()
                                                    });
                                                    updateItem(item.id_product, newQuantity).catch(error => {
                                                        alert('No se pudo actualizar la cantidad del producto. Inténtalo de nuevo.');
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: currentQuantity
                                                        });
                                                        setInputValues({
                                                            ...inputValues,
                                                            [item.id_product]: currentQuantity.toString()
                                                        });
                                                    });
                                                }
                                            }}
                                            className="px-3 py-2 text-lg font-bold text-gray-600 dark:text-gray-400 hover:bg-red-300 dark:hover:bg-red-500 hover:text-black dark:hover:text-white rounded-l-lg transition-colors duration-200 cursor-pointer flex items-center"
                                            aria-label="Disminuir cantidad"
                                        >
                                            <span>-</span>
                                        </button>
                                        <input
                                            type="text"
                                            inputMode="numeric"
                                            value={inputValues[item.id_product] || item.quantity.toString()}
                                            onClick={(e) => {
                                                e.currentTarget.select();
                                            }}
                                            onFocus={(e) => {
                                                e.currentTarget.select();
                                            }}
                                            onChange={(e) => {
                                                const newValue = e.target.value.replace(/[^0-9]/g, '');
                                                setInputValues({
                                                    ...inputValues,
                                                    [item.id_product]: newValue
                                                });
                                                const newQuantity = parseInt(newValue, 10);
                                                if (!isNaN(newQuantity)) {
                                                    if (newQuantity > item.disponibility) {
                                                        setShowMaxAlert(true);
                                                        setTimeout(() => setShowMaxAlert(false), 3000);
                                                    } else {
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: newQuantity || 1
                                                        });
                                                        if (newQuantity >= 1 && newQuantity <= item.disponibility) {
                                                            updateItem(item.id_product, newQuantity);
                                                        }
                                                    }
                                                }
                                            }}
                                            onBlur={() => {
                                                const currentValue = inputValues[item.id_product] || '1';
                                                let newQuantity = parseInt(currentValue, 10);
                                                if (isNaN(newQuantity) || newQuantity < 1) {
                                                    newQuantity = 1;
                                                }
                                                if (newQuantity > item.disponibility) {
                                                    newQuantity = item.disponibility;
                                                    setShowMaxAlert(true);
                                                    setTimeout(() => setShowMaxAlert(false), 3000);
                                                }
                                                setInputValues({
                                                    ...inputValues,
                                                    [item.id_product]: newQuantity.toString()
                                                });
                                                setQuantities({
                                                    ...quantities,
                                                    [item.id_product]: newQuantity
                                                });
                                                updateItem(item.id_product, newQuantity);
                                            }}
                                            className="w-16 px-2 py-2 text-lg font-bold text-gray-800 dark:text-gray-200 bg-white dark:bg-gray-900 text-center border-none focus:outline-none focus:ring-1 focus:ring-blue-500 dark:focus:ring-blue-400"
                                            aria-label="Cantidad"
                                        />
                                        <button
                                            onClick={() => {
                                                const currentQuantity = toInt(quantities[item.id_product] ?? item.quantity, 1);
                                                if (currentQuantity < item.disponibility) {
                                                    const newQuantity = currentQuantity + 1;
                                                    setQuantities({
                                                        ...quantities,
                                                        [item.id_product]: newQuantity
                                                    });
                                                    setInputValues({
                                                        ...inputValues,
                                                        [item.id_product]: newQuantity.toString()
                                                    });
                                                    updateItem(item.id_product, newQuantity).catch(error => {
                                                        alert('No se pudo actualizar la cantidad del producto. Inténtalo de nuevo.');
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: currentQuantity
                                                        });
                                                        setInputValues({
                                                            ...inputValues,
                                                            [item.id_product]: currentQuantity.toString()
                                                        });
                                                    });
                                                } else {
                                                    setShowMaxAlert(true);
                                                    setTimeout(() => setShowMaxAlert(false), 3000);
                                                }
                                            }}
                                            className="px-3 py-2 text-lg font-bold text-gray-600 dark:text-gray-400 hover:bg-green-300 dark:hover:bg-green-500 hover:text-black dark:hover:text-white rounded-r-lg transition-colors duration-200 cursor-pointer flex items-center"
                                            aria-label="Aumentar cantidad"
                                        >
                                            <span>+</span>
                                        </button>
                                    </div>
                                    <p className="text-base font-bold text-[#006CFA] dark:text-[#FBCC13] mt-2">{formatPrice(Number(item.price) * toInt(item.quantity, 1))}</p>
                                </div>
                                <div className="flex flex-col items-center gap-2">
                                    <button
                                        onClick={() => {
                                            removeFromCart(item.id_product);
                                            setShowDeleteMsg(true);
                                            setTimeout(() => setShowDeleteMsg(false), 1500);
                                        }}
                                        className="text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-600 cursor-pointer bg-red-100 dark:bg-red-900 p-2 rounded-full shadow transition-colors duración-200"
                                        aria-label="Eliminar producto"
                                    >
                                        <Trash2 className="h-6 w-6" />
                                    </button>
                                </div>
                            </div>
                            <div className="flex flex-col gap-3 p-4 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-[#FBCC13] dark:border-[#006CFA] sm:hidden w-full transición-transform hover:scale-[1.01]">
                                <div className="flex items-center gap-4">
                                    <img className="w-16 h-16 object-contain rounded-lg border-2 border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900" src={item.image || (document.documentElement.classList.contains('dark') ? '/images/logotipo-claro.png' : '/images/logotipo.png')} alt={item.name} />
                                    <div>
                                        <h3 className="text-base font-bold uppercase text-black dark:text-white mb-1">{item.name} <span className="text-gray-500 dark:text-gray-400">(x{item.quantity})</span></h3>
                                        <p className="text-xs text-gray-600 dark:text-gray-400">Precio: <span className="font-bold">{formatPrice(Number(item.price))}</span></p>
                                        <p className="text-xs text-gray-600 dark:text-gray-400">Disponibles: <span className="font-bold">{item.disponibility}</span></p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 justify-center mt-2">
                                    <div className="flex items-center border border-gray-300 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900 shadow min-w-[140px] justify-center">
                                        <button
                                            onClick={() => {
                                                const currentQuantity = toInt(quantities[item.id_product] ?? item.quantity, 1);
                                                if (currentQuantity > 1) {
                                                    const newQuantity = currentQuantity - 1;
                                                    setQuantities({
                                                        ...quantities,
                                                        [item.id_product]: newQuantity
                                                    });
                                                    setInputValues({
                                                        ...inputValues,
                                                        [item.id_product]: newQuantity.toString()
                                                    });
                                                    updateItem(item.id_product, newQuantity).catch(error => {
                                                        alert('No se pudo actualizar la cantidad del producto. Inténtalo de nuevo.');
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: currentQuantity
                                                        });
                                                        setInputValues({
                                                            ...inputValues,
                                                            [item.id_product]: currentQuantity.toString()
                                                        });
                                                    });
                                                }
                                            }}
                                            className="px-3 py-2 text-lg font-bold text-gray-600 dark:text-gray-400 hover:bg-red-300 dark:hover:bg-red-500 hover:text-black dark:hover:text-white rounded-l-lg transition-colors duration-200 cursor-pointer flex items-center"
                                            aria-label="Disminuir cantidad"
                                        >
                                            <span>-</span>
                                        </button>
                                        <input
                                            type="text"
                                            inputMode="numeric"
                                            value={inputValues[item.id_product] || item.quantity.toString()}
                                            onClick={(e) => {
                                                e.currentTarget.select();
                                            }}
                                            onFocus={(e) => {
                                                e.currentTarget.select();
                                            }}
                                            onChange={(e) => {
                                                const newValue = e.target.value.replace(/[^0-9]/g, '');
                                                setInputValues({
                                                    ...inputValues,
                                                    [item.id_product]: newValue
                                                });
                                                const newQuantity = parseInt(newValue, 10);
                                                // Solo actualizar la cantidad si es un número válido
                                                if (!isNaN(newQuantity)) {
                                                    // Comprobar si excede el límite
                                                    if (newQuantity > item.disponibility) {
                                                        setShowMaxAlert(true);
                                                        setTimeout(() => setShowMaxAlert(false), 3000);
                                                    } else {
                                                        // Actualizar estado local
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: newQuantity || 1
                                                        });
                                                        // Actualizar servidor si es válido
                                                        if (newQuantity >= 1 && newQuantity <= item.disponibility) {
                                                            updateItem(item.id_product, newQuantity);
                                                        }
                                                    }
                                                }
                                            }}
                                            onBlur={() => {
                                                // Validar y corregir cuando el usuario termina de editar
                                                const currentValue = inputValues[item.id_product] || '1';
                                                let newQuantity = parseInt(currentValue, 10);
                                                if (isNaN(newQuantity) || newQuantity < 1) {
                                                    newQuantity = 1;
                                                }
                                                // Limitar al máximo disponible
                                                if (newQuantity > item.disponibility) {
                                                    newQuantity = item.disponibility;
                                                    setShowMaxAlert(true);
                                                    setTimeout(() => setShowMaxAlert(false), 3000);
                                                }
                                                setInputValues({
                                                    ...inputValues,
                                                    [item.id_product]: newQuantity.toString()
                                                });
                                                setQuantities({
                                                    ...quantities,
                                                    [item.id_product]: newQuantity
                                                });
                                                updateItem(item.id_product, newQuantity);
                                            }}
                                            className="w-16 px-2 py-2 text-lg font-bold text-gray-800 dark:text-gray-200 bg-white dark:bg-gray-900 text-center border-none focus:outline-none focus:ring-1 focus:ring-blue-500 dark:focus:ring-blue-400"
                                            aria-label="Cantidad"
                                        />
                                        <button
                                            onClick={() => {
                                                const currentQuantity = toInt(quantities[item.id_product] ?? item.quantity, 1);
                                                if (currentQuantity < item.disponibility) {
                                                    const newQuantity = currentQuantity + 1;
                                                    setQuantities({
                                                        ...quantities,
                                                        [item.id_product]: newQuantity
                                                    });
                                                    setInputValues({
                                                        ...inputValues,
                                                        [item.id_product]: newQuantity.toString()
                                                    });
                                                    updateItem(item.id_product, newQuantity).catch(error => {
                                                        alert('No se pudo actualizar la cantidad del producto. Inténtalo de nuevo.');
                                                        setQuantities({
                                                            ...quantities,
                                                            [item.id_product]: currentQuantity
                                                        });
                                                        setInputValues({
                                                            ...inputValues,
                                                            [item.id_product]: currentQuantity.toString()
                                                        });
                                                    });
                                                } else {
                                                    setShowMaxAlert(true);
                                                    setTimeout(() => setShowMaxAlert(false), 3000);
                                                }
                                            }}
                                            className="px-3 py-2 text-lg font-bold text-gray-600 dark:text-gray-400 hover:bg-green-300 dark:hover:bg-green-500 hover:text-black dark:hover:text-white rounded-r-lg transition-colors duration-200 cursor-pointer flex items-center"
                                            aria-label="Aumentar cantidad"
                                        >
                                            <span>+</span>
                                        </button>
                                    </div>
                                    <span className="text-base font-bold text-[#006CFA] dark:text-[#FBCC13]">{formatPrice(Number(item.price) * toInt(item.quantity, 1))}</span>
                                    <button
                                        onClick={() => {
                                            removeFromCart(item.id_product);
                                            setShowDeleteMsg(true);
                                            setTimeout(() => setShowDeleteMsg(false), 1500);
                                        }}
                                        className="text-red-500 dark:text-red-400 hover-text-red-700 dark:hover-text-red-600 cursor-pointer bg-red-100 dark:bg-red-900 p-2 rounded-full shadow transition-colors duration-200"
                                        title="Eliminar producto"
                                        aria-label="Eliminar producto"
                                    >
                                        <Trash2 className="h-6 w-6" />
                                    </button>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            )}

            {cartItems.length > 0 && (
                <div className="pb-24"></div>
            )}

            {cartItems.length > 0 && (
                <div className="fixed bottom-0 left-0 right-0 z-20 px-4 py-2 bg-gradient-to-t from-white via-white to-white/90 dark:from-gray-900 dark:via-gray-900 dark:to-gray-900/90 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
                    <button
                        onClick={() => Inertia.visit('/confirmation')}
                        className="bg-[#006CFA] dark:bg-[#FBCC13] text-white dark:text-black font-bold py-3 px-6 rounded-lg hover:bg-[#0055c8] dark:hover:bg-[#e0b610] transition-all duration-300 cursor-pointer shadow-md text-base w-full flex items-center justify-center gap-2"
                    >
                        <CreditCard className="h-5 w-5" /> Continuar
                    </button>
                </div>
            )}
        </div>
    );
}
