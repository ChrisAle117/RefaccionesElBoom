import { ProductCatalog } from '@/components/product-catalog';
import { LegalDocuments } from '@/components/LegalDocuments';
import { motion, AnimatePresence } from 'framer-motion';
import { Vacancies } from '@/components/Vacancies';
import React, { useState } from 'react';
import Ubication from '@/components/ubication';
import { Catalog } from '@/components/catalog';
import AboutUs from '@/components/about-us';
import Support from '@/components/Support';
import SocialFeeds from '@/components/SocialFeeds';

//


type Tab = {
    id: string;
    label: string;
    content: React.ReactNode;
};

interface TabNavigationProps {
    tabs?: Tab[];
    defaultActiveTab?: string;
    stickyOffset?: string;
    className?: string;
    contentPadding?: string;
    contentMinHeight?: string;
    showPurchases?: boolean;
    fullWidth?: boolean;
}

export function TabNavigation({
    tabs: customTabs,
    defaultActiveTab,
    stickyOffset = "top-[72px]",
    className = "",
    contentPadding = "p-8",
    contentMinHeight = "min-h-[calc(100vh-300px)]",
    showPurchases = false,
    fullWidth = false
}: TabNavigationProps) {
    // Opciones predefinidas de tabs para todas las páginas
    const defaultTabs: Tab[] = [
        {
            id: 'productos',
            label: 'Productos',
            content: (
                <div className="pt-10 w-full">
                    <ProductCatalog />
                </div>
            )
        },
        {
            id: 'nosotros',
            label: 'Nosotros',
            content: (
                <div className="pt-10">
                    <AboutUs />
                </div>
            )
        },
        {
            id: 'sucursales',
            label: 'Sucursales',
            content: <Ubication />
        },
        // {
        //     id: 'promociones',
        //     label: '¡Promociones!',
        //     content: (
        //         <div className="pt-10">
        //             <h2 className="text-2xl font-bold mb-4 text-[#006CFA]">Promociones Especiales</h2>
        //             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        //                 <div className="bg-white rounded-lg shadow-md overflow-hidden">
        //                     <div className="p-6">
        //                         <h3 className="text-xl font-semibold mb-2">¡Oferta especial!</h3>
        //                         <p className="text-gray-600">Contenido de promoción aquí...</p>
        //                     </div>
        //                 </div>
        //             </div>
        //         </div>
        //     )
        // },
        {
            id: 'vacantes',
            label: 'Bolsa de trabajo',
            content: <Vacancies />
        },
        {
            id: 'catalogos',
            label: 'Catálogos',
            content: <Catalog />
        },
        // {
        //     id: 'servicios',
        //     label: 'Fabricación',
        //     content: (
        //         <div className="pt-10">
        //             <h2 className="text-2xl font-bold mb-4 text-[#006CFA]">Fabricación</h2>
        //             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        //                 <div className="bg-white rounded-lg shadow-md overflow-hidden">
        //                     <div className="p-6">
        //                         <h3 className="text-xl font-semibold mb-2">¡Tanques de agua!</h3>
        //                         <p className="text-gray-600">Info de pipas</p>
        //                     </div>
        //                 </div>
        //             </div>
        //         </div>
        //     )
        // },
        {
            id: 'datos',
            label: 'Redes sociales',
            content: <SocialFeeds />
        },
        {
            id: 'terminos',
            label: 'Avisos',
            content: (
                <div className="pt-10">
                    <LegalDocuments />
                </div>
            )
        },
        {
            id: 'soporte',
            label: 'Soporte',
            content: <Support />
        },
        // {
        //     id: 'Otros',
        //     label: 'Otros',
        //     content: (
        //         <div className="pt-10">
        //             <h2 className="text-2xl font-bold mb-4 text-[#006CFA]">
        //             </h2>
        //             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        //                 <div className="bg-white rounded-lg shadow-md overflow-hidden">
        //                     <div className="p-6">


        //                     </div>
        //                 </div>
        //             </div>
        //         </div>
        //     )
        // },
    ];


    // Determinar qué tabs mostrar
    const tabs = customTabs || (() => {
        let standardTabs = [...defaultTabs];
        if (showPurchases) {
            standardTabs.splice(3, 0);
        }
        return standardTabs;
    })();

    const [activeTab, setActiveTab] = useState(defaultActiveTab || (tabs.length > 0 ? tabs[0].id : ''));

    return (
        <div className={className}>
            {/* Barra de navegación por tabs */}
            <div
                data-coachmark="tabnav"
                className={`sticky ${stickyOffset} z-30 bg-white shadow-md ${fullWidth ? 'w-screen left-0 -ml-[calc(50vw-50%)]' : ''} dark:bg-[#101828] dark:shadow-lg`}
            >
                <div className="container mx-auto flex w-full overflow-x-auto scrollbar-hide">
                    {tabs.map((tab) => (
                        <motion.button
                            key={tab.id}
                            data-tab-id={tab.id}
                            className={`px-6 py-4 font-medium text-sm whitespace-nowrap transition-colors cursor-pointer flex-1 basis-0 text-center ${activeTab === tab.id
                                ? 'text-red-600 border-b-2 border-red-600 dark:text-[#FBCC13] dark:border-[#FBCC13]'
                                : 'text-gray-600 hover:text-black dark:text-gray-300 dark:hover:text-[#FBCC13]'
                                }`}
                            onClick={() => setActiveTab(tab.id)}
                            whileTap={{ scale: 0.95 }}
                            whileHover={{ y: -2 }}
                            transition={{ duration: 0.2 }}
                        >
                            {tab.label}
                        </motion.button>
                    ))}
                </div>
            </div>

            {/* Contenido principal */}
            <div className={`${fullWidth ? 'px-0' : contentPadding}`}>
                <div className={`${contentMinHeight} pb-20 dark:bg-gray-900 dark:text-gray-100 ${fullWidth ? 'w-full' : ''}`}>
                    <AnimatePresence mode="wait">
                        {tabs.map((tab) => (
                            activeTab === tab.id && (
                                <motion.div
                                    key={tab.id}
                                    initial={{ opacity: 0, x: 100 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    exit={{ opacity: 0, x: -100 }}
                                    transition={{ duration: 0.3, ease: "easeInOut" }}
                                >
                                    {tab.content}
                                </motion.div>
                            )
                        ))}
                    </AnimatePresence>
                </div>
            </div>
        </div>
    );
}