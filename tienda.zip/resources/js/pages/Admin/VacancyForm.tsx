
import React, { useState } from 'react';
import { Head, useForm } from '@inertiajs/react';
import AdminLayout from '@/layouts/admin-layout';

interface VacancyFormProps {
    vacancy?: {
        id: number;
        title: string;
        department: string;
        location: string;
        description: string;
        requirements: string[];
        benefits: string[];
        contact_email: string;
        active: boolean;
    };
    departments: string[];
    locations: string[];
}

const VacancyForm: React.FC<VacancyFormProps> = ({ vacancy, departments, locations }) => {
    const isEditMode = !!vacancy;
    
    const [inputMode, setInputMode] = useState({
        department: false,
        location: false
    });
    
    const { data, setData, errors, post, put, processing } = useForm({
        title: vacancy?.title || '',
        department: vacancy?.department || '',
        location: vacancy?.location || '',
        description: vacancy?.description || '',
        requirements: vacancy?.requirements || [''],
        benefits: vacancy?.benefits || [''],
        contact_email: vacancy?.contact_email || 'capitalhumano@refaccioneselboom.com',
        active: vacancy?.active ?? true
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (isEditMode) {
            put(route('admin.vacancies.update', vacancy.id));
        } else {
            post(route('admin.vacancies.store'));
        }
    };

    // Manejar requisitos como array dinámico
    const handleRequirementChange = (index: number, value: string) => {
        const updatedRequirements = [...data.requirements];
        updatedRequirements[index] = value;
        setData('requirements', updatedRequirements);
    };

    const addRequirement = () => {
        setData('requirements', [...data.requirements, '']);
    };

    const removeRequirement = (index: number) => {
        if (data.requirements.length > 1) {
            const updatedRequirements = [...data.requirements];
            updatedRequirements.splice(index, 1);
            setData('requirements', updatedRequirements);
        }
    };

    // Manejar beneficios como array dinámico
    const handleBenefitChange = (index: number, value: string) => {
        const updatedBenefits = [...data.benefits];
        updatedBenefits[index] = value;
        setData('benefits', updatedBenefits);
    };

    const addBenefit = () => {
        setData('benefits', [...data.benefits, '']);
    };

    const removeBenefit = (index: number) => {
        if (data.benefits.length > 1) {
            const updatedBenefits = [...data.benefits];
            updatedBenefits.splice(index, 1);
            setData('benefits', updatedBenefits);
        }
    };

    return (
        <AdminLayout>
            <Head title={isEditMode ? 'Editar Vacante' : 'Crear Vacante'} />

            <div className="container mx-auto p-4">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold">{isEditMode ? 'Editar Vacante' : 'Crear Nueva Vacante'}</h1>
                </div>

                <div className="bg-white rounded-lg shadow-md p-6">
                    <form onSubmit={handleSubmit}>
                        {/* Título de la vacante */}
                        <div className="mb-4">
                            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                                Título de la vacante *
                            </label>
                            <input
                                id="title"
                                type="text"
                                className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                value={data.title}
                                onChange={(e) => setData('title', e.target.value)}
                                required
                            />
                            {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label htmlFor="department" className="block text-sm font-medium text-gray-700 mb-1">
                                    Departamento *
                                </label>
                                <div className="mb-1 flex items-center">
                                    <label className="flex items-center text-sm text-gray-600 mr-4">
                                        <input
                                            type="radio"
                                            className="form-radio h-4 w-4 text-[#006CFA]"
                                            checked={!inputMode.department}
                                            onChange={() => setInputMode({...inputMode, department: false})}
                                        />
                                        <span className="ml-1">Seleccionar existente</span>
                                    </label>
                                    <label className="flex items-center text-sm text-gray-600">
                                        <input
                                            type="radio"
                                            className="form-radio h-4 w-4 text-[#006CFA]"
                                            checked={inputMode.department}
                                            onChange={() => setInputMode({...inputMode, department: true})}
                                        />
                                        <span className="ml-1">Nuevo departamento</span>
                                    </label>
                                </div>

                                {!inputMode.department && departments.length > 0 ? (
                                    <select
                                        id="department"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={data.department}
                                        onChange={(e) => setData('department', e.target.value)}
                                        required
                                    >
                                        <option value="">Seleccione un departamento</option>
                                        {departments.map((dept, index) => (
                                            <option key={index} value={dept}>{dept}</option>
                                        ))}
                                    </select>
                                ) : (
                                    <input
                                        id="department"
                                        type="text"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={data.department}
                                        onChange={(e) => setData('department', e.target.value)}
                                        placeholder="Ej: Ventas, Recursos Humanos, Logística"
                                        required
                                    />
                                )}
                                {errors.department && <p className="text-red-500 text-sm mt-1">{errors.department}</p>}
                            </div>

                            <div>
                                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                                    Ubicación *
                                </label>
                                <div className="mb-1 flex items-center">
                                    <label className="flex items-center text-sm text-gray-600 mr-4">
                                        <input
                                            type="radio"
                                            className="form-radio h-4 w-4 text-[#006CFA]"
                                            checked={!inputMode.location}
                                            onChange={() => setInputMode({...inputMode, location: false})}
                                        />
                                        <span className="ml-1">Seleccionar existente</span>
                                    </label>
                                    <label className="flex items-center text-sm text-gray-600">
                                        <input
                                            type="radio"
                                            className="form-radio h-4 w-4 text-[#006CFA]"
                                            checked={inputMode.location}
                                            onChange={() => setInputMode({...inputMode, location: true})}
                                        />
                                        <span className="ml-1">Nueva ubicación</span>
                                    </label>
                                </div>

                                {!inputMode.location && locations.length > 0 ? (
                                    <select
                                        id="location"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={data.location}
                                        onChange={(e) => setData('location', e.target.value)}
                                        required
                                    >
                                        <option value="">Seleccione una ubicación</option>
                                        {locations.map((loc, index) => (
                                            <option key={index} value={loc}>{loc}</option>
                                        ))}
                                    </select>
                                ) : (
                                    <input
                                        id="location"
                                        type="text"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={data.location}
                                        onChange={(e) => setData('location', e.target.value)}
                                        placeholder="Ej: Cuernavaca, Morelos"
                                        required
                                    />
                                )}
                                {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
                            </div>
                        </div>

                        {/* Descripción */}
                        <div className="mb-4">
                            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                                Descripción *
                            </label>
                            <textarea
                                id="description"
                                rows={4}
                                className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                value={data.description}
                                onChange={(e) => setData('description', e.target.value)}
                                required
                            ></textarea>
                            {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
                        </div>

                        {/* Requisitos */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Requisitos *
                            </label>
                            {data.requirements.map((requirement, index) => (
                                <div key={index} className="flex mb-2">
                                    <input
                                        type="text"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={requirement}
                                        onChange={(e) => handleRequirementChange(index, e.target.value)}
                                        placeholder="Añadir requisito"
                                        required
                                    />
                                    <button
                                        type="button"
                                        className="ml-2 bg-red-500 text-white text-sm px-2 py-1 rounded border border-red-600 hover:bg-red-600 transition-colors"
                                        onClick={() => removeRequirement(index)}
                                        disabled={data.requirements.length <= 1}
                                    >
                                        -
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                className="mt-2 bg-[#006CFA] text-white text-sm px-3 py-1.5 rounded border border-blue-700 hover:bg-blue-600 transition-colors"
                                onClick={addRequirement}
                            >
                                + Añadir requisito
                            </button>
                            {errors.requirements && <p className="text-red-500 text-sm mt-1">{errors.requirements}</p>}
                        </div>

                        {/* Beneficios */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Beneficios *
                            </label>
                            {data.benefits.map((benefit, index) => (
                                <div key={index} className="flex mb-2">
                                    <input
                                        type="text"
                                        className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                        value={benefit}
                                        onChange={(e) => handleBenefitChange(index, e.target.value)}
                                        placeholder="Añadir beneficio"
                                        required
                                    />
                                    <button
                                        type="button"
                                        className="ml-2 bg-red-500 text-white text-sm px-2 py-1 rounded border border-red-600 hover:bg-red-600 transition-colors"
                                        onClick={() => removeBenefit(index)}
                                        disabled={data.benefits.length <= 1}
                                    >
                                        -
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                className="mt-2 bg-[#006CFA] text-white text-sm px-3 py-1.5 rounded border border-blue-700 hover:bg-blue-600 transition-colors"
                                onClick={addBenefit}
                            >
                                + Añadir beneficio
                            </button>
                            {errors.benefits && <p className="text-red-500 text-sm mt-1">{errors.benefits}</p>}
                        </div>

                        {/* Email de contacto */}
                        <div className="mb-4">
                            <label htmlFor="contact_email" className="block text-sm font-medium text-gray-700 mb-1">
                                Email de contacto *
                            </label>
                            <input
                                id="contact_email"
                                type="email"
                                className="w-full rounded-md border border-gray-300 focus:border-[#006CFA] focus:ring focus:ring-blue-200 focus:ring-opacity-50 px-3 py-2"
                                value={data.contact_email}
                                onChange={(e) => setData('contact_email', e.target.value)}
                                required
                            />
                            {errors.contact_email && <p className="text-red-500 text-sm mt-1">{errors.contact_email}</p>}
                        </div>

                        {/* Estado activo */}
                        <div className="mb-6">
                            <label className="flex items-center">
                                <input
                                    type="checkbox"
                                    className="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                    checked={data.active}
                                    onChange={(e) => setData('active', e.target.checked)}
                                />
                                <span className="ml-2 text-sm text-gray-700">Vacante Activa</span>
                            </label>
                            <p className="text-sm text-gray-500 mt-1">
                                Las vacantes inactivas no se mostrarán en el sitio web.
                            </p>
                        </div>

                        {/* Botones de acción */}
                        <div className="flex justify-end space-x-2">
                            <a
                                href={route('admin.vacancies.index')}
                                className="px-3 py-1.5 bg-gray-200 text-gray-800 text-sm rounded border border-gray-300 hover:bg-gray-300 transition-colors"
                            >
                                Cancelar
                            </a>
                            <button
                                type="submit"
                                className="px-4 py-1.5 bg-[#006CFA] cursor-pointer text-white text-sm rounded border border-blue-700 hover:bg-blue-600 transition-colors flex items-center"
                                disabled={processing}
                            >
                                {processing ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        {isEditMode ? 'Guardando...' : 'Creando...'}
                                    </>
                                ) : (
                                    isEditMode ? 'Guardar Cambios' : 'Crear Vacante'
                                )}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </AdminLayout>
    );
};

export default VacancyForm;