<img 
    src="/images/logotipo.png" 
    alt="Mi Logo" 
    class="w-655 h-20 mx-auto"
/>

